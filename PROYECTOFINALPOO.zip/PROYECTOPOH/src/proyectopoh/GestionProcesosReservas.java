/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package proyectopoh;

/**
 *
 * @author marce
 */

import java.util.Date;

public interface GestionProcesosReservas {
    Reserva crearReserva(Huesped h, Habitacion hab, Date inicio, Date fin);
    void checkIn(Reserva r);
    void checkOut(Reserva r);
    void agregarServicioAReserva(Reserva r, ServicioAdicional serv, int cantidad);
    void listarReservas();
}
