/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectopoh;

/**
 *
 * @author eduar
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.Calendar;
import java.util.Date;

public class VentanaHotel extends JFrame {

    
    private Administrador admin;
    private Recepcionista recep;

    
    private Empleado empleadoActual;

    
    private JTabbedPane tabs;
    private JPanel panelAutenticador;
    private JPanel panelAdministrador;
    private JPanel panelRecepcionista;

    
    private JTextField txtAuthDni;
    private JTextField txtAuthNombres;
    private JTextField txtAuthApellidos;
    private JTextField txtAuthUsuario;
    private JPasswordField txtAuthPassword;
    private JTextField txtAuthAcceso;
    private JButton btnAuthLogin;

    
    private JTextField txtHabNumero;
    private JTextField txtHabTipo;
    private JTextField txtHabPrecio;
    private JButton btnRegHab;
    private JButton btnElimHab;
    private JButton btnLimpiarHab;
    private DefaultListModel<String> modeloHab;
    private JList<String> listHab;

    
    private JTextField txtServNombre;
    private JTextField txtServPrecio;
    private JButton btnRegServ;
    private JButton btnElimServ;
    private DefaultListModel<String> modeloServ;
    private JList<String> listServ;

    
    private JTextField txtEmpDni;
    private JTextField txtEmpNom;
    private JTextField txtEmpApe;
    private JTextField txtEmpUser;
    private JTextField txtEmpPass;
    private JTextField txtEmpRol;
    private JTextField txtEmpDniAccion;
    private JButton btnEmpReg;
    private JButton btnEmpMod;
    private JButton btnEmpDel;
    private DefaultListModel<String> modeloEmp;
    private JList<String> listEmp;

    private JButton btnAdminReset;
    private JButton btnAdminLogout;

    
    private Habitacion[] habitacionesUI = new Habitacion[100];
    private int cantHabUI = 0;
    private ServicioAdicional[] serviciosUI = new ServicioAdicional[100];
    private int cantServUI = 0;
    private Empleado[] empleadosUI = new Empleado[50];
    private int cantEmpUI = 0;

    
    private JTextField txtHuespedDni;
    private JTextField txtHuespedNombres;
    private JTextField txtHuespedApellidos;
    private JTextField txtHuespedTelefono;
    private JButton btnRegHuesped;
    private JButton btnBuscarHuesped;
    private JButton btnElimHuesped;
    private DefaultListModel<String> modeloHuespedes;
    private JList<String> listHuespedes;

    
    private JTextField txtResDni;
    private JTextField txtResNumHab;
    private JTextField txtResDias;
    private JButton btnCrearReserva;
    private JButton btnCheckIn;
    private JButton btnCheckOut;
    private JTextField txtResServNombre;
    private JTextField txtResServCantidad;
    private JButton btnAgregarServicio;
    private DefaultListModel<String> modeloReservas;
    private JList<String> listReservas;

    private JButton btnRecepReset;
    private JButton btnRecepLogout;

   
    private Huesped[] huespedesUI = new Huesped[100];
    private int cantHuespedesUI = 0;
    private Reserva[] reservasUI = new Reserva[100];
    private int cantReservasUI = 0;

    public VentanaHotel() {
        
        admin = new Administrador("0001", "Carlos", "Perez", "carlos", "adminpass", false);
        recep = new Recepcionista("0002", "Ana", "Gomez", "ana", "receppass", false);

        
        empleadosUI[0] = admin;
        empleadosUI[1] = recep;
        cantEmpUI = 2;

        setTitle("Sistema Hotel - POO");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1100, 650);
        setLocationRelativeTo(null);

        tabs = new JTabbedPane();


        panelAutenticador = crearPanelAutenticador();
        panelAdministrador = crearPanelAdministrador();
        panelRecepcionista = crearPanelRecepcionista();

        
        tabs.add("Autenticador", panelAutenticador);

        add(tabs);
    }

    
    private JPanel crearPanelAutenticador() {
        JPanel panel = new JPanel(new BorderLayout());
        JPanel centro = new JPanel(new GridLayout(3, 4, 5, 10));

        txtAuthDni = new JTextField();
        txtAuthNombres = new JTextField();
        txtAuthApellidos = new JTextField();
        txtAuthUsuario = new JTextField();
        txtAuthPassword = new JPasswordField();
        txtAuthAcceso = new JTextField("Concedido/Denegado");

        txtAuthDni.setEditable(false);
        txtAuthNombres.setEditable(false);
        txtAuthApellidos.setEditable(false);
        txtAuthAcceso.setEditable(false);

        centro.add(crearLabelNegrita("DNI"));
        centro.add(txtAuthDni);
        centro.add(crearLabelNegrita("Usuario"));
        centro.add(txtAuthUsuario);

        centro.add(crearLabelNegrita("Nombres"));
        centro.add(txtAuthNombres);
        centro.add(crearLabelNegrita("Contraseña"));
        centro.add(txtAuthPassword);

        centro.add(crearLabelNegrita("Apellidos"));
        centro.add(txtAuthApellidos);
        centro.add(crearLabelNegrita("Acceso"));
        centro.add(txtAuthAcceso);

        btnAuthLogin = new JButton("Iniciar sesión");
        btnAuthLogin.addActionListener(this::accionAutenticar);

        panel.add(new JLabel("   Autenticador", SwingConstants.LEFT), BorderLayout.NORTH);
        panel.add(centro, BorderLayout.CENTER);
        panel.add(btnAuthLogin, BorderLayout.SOUTH);

        return panel;
    }

    
    private void accionAutenticar(ActionEvent e) {
        String user = txtAuthUsuario.getText().trim();
        String pass = new String(txtAuthPassword.getPassword());

        Empleado encontrado = buscarEmpleadoPorLogin(user, pass);

        if (encontrado == null) {
            txtAuthDni.setText("");
            txtAuthNombres.setText("");
            txtAuthApellidos.setText("");
            txtAuthAcceso.setText("Denegado");
            JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos");
            return;
        }

        
        empleadoActual = encontrado;

        txtAuthDni.setText(empleadoActual.getDni());
        txtAuthNombres.setText(empleadoActual.getNombres());
        txtAuthApellidos.setText(empleadoActual.getApellidos());
        txtAuthAcceso.setText("Concedido");

        
        tabs.removeAll();

        if (empleadoActual instanceof Administrador) {
            tabs.addTab("Administrador", panelAdministrador);
            tabs.addTab("Recepcionista", panelRecepcionista);
        } else if (empleadoActual instanceof Recepcionista) {
            tabs.addTab("Recepcionista", panelRecepcionista);
        }

        
        tabs.setSelectedIndex(0);
        tabs.updateUI();
    }

    private Empleado buscarEmpleadoPorLogin(String login, String password) {
        for (int i = 0; i < cantEmpUI; i++) {
            Empleado emp = empleadosUI[i];
            if (emp != null && emp.iniciarSesion(login, password)) {
                return emp;
            }
        }
        return null;
    }

    private JPanel crearPanelAdministrador() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new JLabel("   Administrador", SwingConstants.LEFT), BorderLayout.NORTH);

        JPanel centro = new JPanel(new GridLayout(1, 2));

        JPanel panelHab = new JPanel();
        panelHab.setLayout(new BoxLayout(panelHab, BoxLayout.Y_AXIS));

        panelHab.add(crearLabelNegrita("Habitaciones"));
        panelHab.add(Box.createVerticalStrut(5));

        JPanel fila1 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        btnRegHab = new JButton("Registrar hab.");
        txtHabNumero = new JTextField(5);
        txtHabTipo = new JTextField(7);
        txtHabPrecio = new JTextField(7);
        fila1.add(btnRegHab);
        fila1.add(new JLabel("N°:"));
        fila1.add(txtHabNumero);
        fila1.add(new JLabel("Tipo:"));
        fila1.add(txtHabTipo);
        fila1.add(new JLabel("Precio:"));
        fila1.add(txtHabPrecio);
        panelHab.add(fila1);

        JPanel fila2 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        btnElimHab = new JButton("Eliminar hab.");
        JTextField txtHabNumEliminar = new JTextField(5);
        fila2.add(btnElimHab);
        fila2.add(new JLabel("N°:"));
        fila2.add(txtHabNumEliminar);
        panelHab.add(fila2);

        JPanel fila3 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        btnLimpiarHab = new JButton("Marcar limpia");
        JTextField txtHabNumLimpiar = new JTextField(5);
        fila3.add(btnLimpiarHab);
        fila3.add(new JLabel("N°:"));
        fila3.add(txtHabNumLimpiar);
        panelHab.add(fila3);

        panelHab.add(Box.createVerticalStrut(10));
        panelHab.add(crearLabelNegrita("Lista habitaciones"));
        modeloHab = new DefaultListModel<>();
        listHab = new JList<>(modeloHab);
        panelHab.add(new JScrollPane(listHab));

        btnRegHab.addActionListener(ev -> {
            try {
                int num = Integer.parseInt(txtHabNumero.getText().trim());
                String tipo = txtHabTipo.getText().trim();
                double precio = Double.parseDouble(txtHabPrecio.getText().trim());
                Habitacion h = new Habitacion(num, tipo, precio, "limpia");
                admin.registrarHabitacion(h);

                if (cantHabUI < habitacionesUI.length) {
                    habitacionesUI[cantHabUI++] = h;
                    modeloHab.addElement(h.VerInfo());
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Datos de habitación inválidos");
            }
        });

        btnElimHab.addActionListener(ev -> {
            try {
                int num = Integer.parseInt(txtHabNumEliminar.getText().trim());
                admin.eliminarHabitacion(num);
                for (int i = 0; i < cantHabUI; i++) {
                    if (habitacionesUI[i].getNumero() == num) {
                        modeloHab.remove(i);
                        habitacionesUI[i] = habitacionesUI[cantHabUI - 1];
                        habitacionesUI[cantHabUI - 1] = null;
                        cantHabUI--;
                        break;
                    }
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Número inválido");
            }
        });

        btnLimpiarHab.addActionListener(ev -> {
            try {
                int num = Integer.parseInt(txtHabNumLimpiar.getText().trim());
                admin.limpiarHabitacion(num);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Número inválido");
            }
        });

        JPanel panelServEmp = new JPanel();
        panelServEmp.setLayout(new BoxLayout(panelServEmp, BoxLayout.Y_AXIS));

        panelServEmp.add(crearLabelNegrita("Servicios adicionales"));
        panelServEmp.add(Box.createVerticalStrut(5));

        JPanel filaS1 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        btnRegServ = new JButton("Registrar serv.");
        txtServNombre = new JTextField(10);
        txtServPrecio = new JTextField(7);
        filaS1.add(btnRegServ);
        filaS1.add(new JLabel("Nombre:"));
        filaS1.add(txtServNombre);
        filaS1.add(new JLabel("Precio:"));
        filaS1.add(txtServPrecio);
        panelServEmp.add(filaS1);

        JPanel filaS2 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        btnElimServ = new JButton("Eliminar serv.");
        JTextField txtServEliminar = new JTextField(10);
        filaS2.add(btnElimServ);
        filaS2.add(new JLabel("Nombre:"));
        filaS2.add(txtServEliminar);
        panelServEmp.add(filaS2);

        panelServEmp.add(Box.createVerticalStrut(10));
        panelServEmp.add(crearLabelNegrita("Lista de servicios"));
        modeloServ = new DefaultListModel<>();
        listServ = new JList<>(modeloServ);
        panelServEmp.add(new JScrollPane(listServ));

        btnRegServ.addActionListener(ev -> {
            try {
                String nom = txtServNombre.getText().trim();
                double precio = Double.parseDouble(txtServPrecio.getText().trim());
                ServicioAdicional s = new ServicioAdicional(nom, precio);
                admin.registrarServicio(s);
                if (cantServUI < serviciosUI.length) {
                    serviciosUI[cantServUI++] = s;
                    modeloServ.addElement(s.VerInfo());
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Datos de servicio inválidos");
            }
        });

        btnElimServ.addActionListener(ev -> {
            String nom = txtServEliminar.getText().trim();
            admin.eliminarServicio(nom);
            for (int i = 0; i < cantServUI; i++) {
                if (serviciosUI[i].getNombre().equalsIgnoreCase(nom)) {
                    modeloServ.remove(i);
                    serviciosUI[i] = serviciosUI[cantServUI - 1];
                    serviciosUI[cantServUI - 1] = null;
                    cantServUI--;
                    break;
                }
            }
        });

        panelServEmp.add(Box.createVerticalStrut(15));
        panelServEmp.add(crearLabelNegrita("Gestión de empleados"));
        panelServEmp.add(Box.createVerticalStrut(5));

        JPanel filaE1 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        txtEmpDni = new JTextField(8);
        txtEmpNom = new JTextField(8);
        txtEmpApe = new JTextField(8);
        filaE1.add(new JLabel("DNI:"));
        filaE1.add(txtEmpDni);
        filaE1.add(new JLabel("Nom:"));
        filaE1.add(txtEmpNom);
        filaE1.add(new JLabel("Ape:"));
        filaE1.add(txtEmpApe);
        panelServEmp.add(filaE1);

        JPanel filaE2 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        txtEmpUser = new JTextField(8);
        txtEmpPass = new JTextField(8);
        txtEmpRol = new JTextField(10); // "ADMIN" o "RECEPCIONISTA"
        filaE2.add(new JLabel("User:"));
        filaE2.add(txtEmpUser);
        filaE2.add(new JLabel("Pass:"));
        filaE2.add(txtEmpPass);
        filaE2.add(new JLabel("Rol:"));
        filaE2.add(txtEmpRol);
        panelServEmp.add(filaE2);

        JPanel filaE3 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        btnEmpReg = new JButton("Reg. emp");
        btnEmpMod = new JButton("Mod. emp");
        btnEmpDel = new JButton("Elim. emp");
        txtEmpDniAccion = new JTextField(8); // DNI para modificar/eliminar
        filaE3.add(btnEmpReg);
        filaE3.add(btnEmpMod);
        filaE3.add(btnEmpDel);
        filaE3.add(new JLabel("DNI:"));
        filaE3.add(txtEmpDniAccion);
        panelServEmp.add(filaE3);

        panelServEmp.add(Box.createVerticalStrut(5));
        panelServEmp.add(crearLabelNegrita("Lista de empleados"));
        modeloEmp = new DefaultListModel<>();
        listEmp = new JList<>(modeloEmp);
        panelServEmp.add(new JScrollPane(listEmp));

        btnEmpReg.addActionListener(ev -> {
            String dni = txtEmpDni.getText().trim();
            String nom = txtEmpNom.getText().trim();
            String ape = txtEmpApe.getText().trim();
            String user = txtEmpUser.getText().trim();
            String pass = txtEmpPass.getText().trim();
            String rol = txtEmpRol.getText().trim();

            if (dni.isEmpty() || nom.isEmpty() || rol.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Complete al menos DNI, nombre y rol");
                return;
            }

            admin.registrarEmpleado(rol, dni, nom, ape, user, pass);

            if (cantEmpUI < empleadosUI.length) {
                Empleado nuevo;
                if (rol.equalsIgnoreCase("ADMIN") || rol.equalsIgnoreCase("ADMINISTRADOR")) {
                    nuevo = new Administrador(dni, nom, ape, user, pass, true);
                } else {
                    nuevo = new Recepcionista(dni, nom, ape, user, pass, true);
                }
                empleadosUI[cantEmpUI] = nuevo;
                modeloEmp.addElement(formatearEmpleado(nuevo));
                cantEmpUI++;
            }
        });

        btnEmpMod.addActionListener(ev -> {
            String dniAcc = txtEmpDniAccion.getText().trim();
            String nuevosNom = txtEmpNom.getText().trim();
            String nuevosApe = txtEmpApe.getText().trim();

            if (dniAcc.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Ingrese DNI para modificar");
                return;
            }

            admin.modificarEmpleado(dniAcc, nuevosNom, nuevosApe);

            for (int i = 0; i < cantEmpUI; i++) {
                if (empleadosUI[i].getDni().equals(dniAcc)) {
                    if (!nuevosNom.isEmpty()) {
                        empleadosUI[i].setNombres(nuevosNom);
                    }
                    if (!nuevosApe.isEmpty()) {
                        empleadosUI[i].setApellidos(nuevosApe);
                    }
                    modeloEmp.set(i, formatearEmpleado(empleadosUI[i]));
                    break;
                }
            }
        });

        btnEmpDel.addActionListener(ev -> {
            String dniAcc = txtEmpDniAccion.getText().trim();
            if (dniAcc.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Ingrese DNI para eliminar");
                return;
            }

            admin.eliminarEmpleado(dniAcc);

            for (int i = 0; i < cantEmpUI; i++) {
                if (empleadosUI[i].getDni().equals(dniAcc)) {
                    modeloEmp.remove(i);
                    empleadosUI[i] = empleadosUI[cantEmpUI - 1];
                    empleadosUI[cantEmpUI - 1] = null;
                    cantEmpUI--;
                    break;
                }
            }
        });

        btnAdminReset = new JButton("Resetear Info");
        btnAdminLogout = new JButton("Cerrar sesión");
        JButton btnReporteOcup = new JButton("Reporte Ocupación");
        JButton btnReporteIngresos = new JButton("Reporte Ingresos");

        btnAdminReset.addActionListener(ev -> {
            admin.resetearInformacion();
            JOptionPane.showMessageDialog(this, "Información del administrador reseteada.");
        });

        btnAdminLogout.addActionListener(ev -> cerrarSesion());

        btnReporteOcup.addActionListener(ev -> {
            if (cantHabUI == 0) {
                JOptionPane.showMessageDialog(this, "No hay habitaciones registradas.");
                return;
            }

            StringBuilder sb = new StringBuilder("REPORTE DE OCUPACIÓN\n\n");
            for (int i = 0; i < cantHabUI; i++) {
                Habitacion h = habitacionesUI[i];
                if (h != null) {
                    sb.append("Hab. ").append(h.getNumero())
                      .append(" | Tipo: ").append(h.getTipo())
                      .append(" | Estado: ").append(h.getEstado())
                      .append("\n");
                }
            }

            JTextArea area = new JTextArea(sb.toString());
            area.setEditable(false);
            JScrollPane sp = new JScrollPane(area);
            sp.setPreferredSize(new Dimension(400, 250));

            JOptionPane.showMessageDialog(this, sp,
                    "Reporte de ocupación", JOptionPane.INFORMATION_MESSAGE);
        });

        btnReporteIngresos.addActionListener(ev -> {
            if (cantReservasUI == 0) {
                JOptionPane.showMessageDialog(this, "No hay reservas registradas.");
                return;
            }

            String inicioStr = JOptionPane.showInputDialog(this,
                    "Fecha inicio (yyyy-mm-dd):");
            if (inicioStr == null || inicioStr.trim().isEmpty()) return;

            String finStr = JOptionPane.showInputDialog(this,
                    "Fecha fin (yyyy-mm-dd):");
            if (finStr == null || finStr.trim().isEmpty()) return;

            try {
                Date inicio = parseFechaSimple(inicioStr.trim());
                Date fin = parseFechaSimple(finStr.trim());

                if (inicio.after(fin)) {
                    JOptionPane.showMessageDialog(this,
                            "La fecha de inicio es mayor que la fecha fin");
                    return;
                }

                double totalHab = 0;
                double totalServ = 0;

                StringBuilder sb = new StringBuilder("REPORTE DE INGRESOS\n");
                sb.append("Rango: ").append(inicioStr).append(" a ").append(finStr).append("\n\n");

                for (int i = 0; i < cantReservasUI; i++) {
                    Reserva r = reservasUI[i];
                    if (r == null) continue;

                    Date ri = r.getFechaInicio();
                    Date rf = r.getFechaFin();

                    if (!ri.before(inicio) && !rf.after(fin)) {
                        int noches = r.calcularNoches();
                        double ingresoHab = noches * r.getHabitacion().getPrecioPorNoche();
                        double ingresoTotal = r.calcularTotal();
                        double ingresoServ = ingresoTotal - ingresoHab;

                        totalHab += ingresoHab;
                        totalServ += ingresoServ;

                        sb.append("Reserva de ")
                          .append(r.getHuesped().getNombres())
                          .append(" | Hab ").append(r.getHabitacion().getNumero())
                          .append(" | Hab: S/. ").append(ingresoHab)
                          .append(" | Serv: S/. ").append(ingresoServ)
                          .append("\n");
                    }
                }

                sb.append("\nTOTAL Habitaciones: S/. ").append(totalHab);
                sb.append("\nTOTAL Servicios:    S/. ").append(totalServ);
                sb.append("\nTOTAL GENERAL:      S/. ").append(totalHab + totalServ);

                JTextArea area = new JTextArea(sb.toString());
                area.setEditable(false);
                JScrollPane sp = new JScrollPane(area);
                sp.setPreferredSize(new Dimension(450, 300));

                JOptionPane.showMessageDialog(this, sp,
                        "Reporte de ingresos", JOptionPane.INFORMATION_MESSAGE);

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this,
                        "Fechas inválidas. Usa formato yyyy-mm-dd",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        JPanel sur = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        sur.add(btnReporteOcup);
        sur.add(btnReporteIngresos);
        sur.add(btnAdminReset);
        sur.add(btnAdminLogout);

        centro.add(panelHab);
        centro.add(panelServEmp);
        panel.add(centro, BorderLayout.CENTER);
        panel.add(sur, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel crearPanelRecepcionista() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new JLabel("   Recepcionista", SwingConstants.LEFT), BorderLayout.NORTH);

        JPanel centro = new JPanel(new GridLayout(1, 2));

        JPanel panelHues = new JPanel();
        panelHues.setLayout(new BoxLayout(panelHues, BoxLayout.Y_AXIS));

        panelHues.add(crearLabelNegrita("Huéspedes"));
        panelHues.add(Box.createVerticalStrut(5));

        txtHuespedDni = new JTextField(8);
        txtHuespedNombres = new JTextField(10);
        txtHuespedApellidos = new JTextField(10);
        txtHuespedTelefono = new JTextField(8);

        JPanel fH1 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        btnRegHuesped = new JButton("Registrar hspd");
        fH1.add(btnRegHuesped);
        fH1.add(new JLabel("DNI:"));
        fH1.add(txtHuespedDni);
        panelHues.add(fH1);

        JPanel fH2 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        fH2.add(new JLabel("Nom:"));
        fH2.add(txtHuespedNombres);
        fH2.add(new JLabel("Ape:"));
        fH2.add(txtHuespedApellidos);
        panelHues.add(fH2);

        JPanel fH3 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        fH3.add(new JLabel("Tel:"));
        fH3.add(txtHuespedTelefono);
        panelHues.add(fH3);

        JPanel fH4 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        btnBuscarHuesped = new JButton("Encontrar hspd.");
        btnElimHuesped = new JButton("Eliminar hspd.");
        JTextField txtDniBuscar = new JTextField(8);
        fH4.add(btnBuscarHuesped);
        fH4.add(btnElimHuesped);
        fH4.add(new JLabel("DNI:"));
        fH4.add(txtDniBuscar);
        panelHues.add(fH4);

        panelHues.add(Box.createVerticalStrut(10));
        panelHues.add(crearLabelNegrita("Lista huéspedes"));
        modeloHuespedes = new DefaultListModel<>();
        listHuespedes = new JList<>(modeloHuespedes);
        panelHues.add(new JScrollPane(listHuespedes));

        btnRegHuesped.addActionListener(ev -> {
            String dni = txtHuespedDni.getText().trim();
            String nom = txtHuespedNombres.getText().trim();
            String ape = txtHuespedApellidos.getText().trim();
            String tel = txtHuespedTelefono.getText().trim();
            if (dni.isEmpty() || nom.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Complete al menos DNI y nombre");
                return;
            }
            Huesped h = new Huesped(dni, nom, ape, tel);
            recep.registrarHuesped(h);
            if (cantHuespedesUI < huespedesUI.length) {
                huespedesUI[cantHuespedesUI++] = h;
                modeloHuespedes.addElement(h.VerInfo());
            }
        });

        btnBuscarHuesped.addActionListener(ev -> {
            String dni = txtDniBuscar.getText().trim();
            Huesped encontrado = buscarHuespedUI(dni);
            if (encontrado != null) {
                JOptionPane.showMessageDialog(this,
                        "Encontrado:\n" + encontrado.VerInfo() +
                                "\nTel: " + encontrado.getTelefono());
            } else {
                JOptionPane.showMessageDialog(this, "Huésped no encontrado");
            }
        });

        btnElimHuesped.addActionListener(ev -> {
            String dni = txtDniBuscar.getText().trim();
            recep.eliminarHuesped(dni);
            for (int i = 0; i < cantHuespedesUI; i++) {
                if (huespedesUI[i].getDni().equals(dni)) {
                    modeloHuespedes.remove(i);
                    huespedesUI[i] = huespedesUI[cantHuespedesUI - 1];
                    huespedesUI[cantHuespedesUI - 1] = null;
                    cantHuespedesUI--;
                    break;
                }
            }
        });

        JPanel panelRes = new JPanel();
        panelRes.setLayout(new BoxLayout(panelRes, BoxLayout.Y_AXIS));

        panelRes.add(crearLabelNegrita("Reservas"));
        panelRes.add(Box.createVerticalStrut(5));

        JPanel fR1 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        btnCrearReserva = new JButton("Crear Reserva");
        txtResDni = new JTextField(8);
        txtResNumHab = new JTextField(5);
        txtResDias = new JTextField(3);
        fR1.add(btnCrearReserva);
        fR1.add(new JLabel("DNI huésped:"));
        fR1.add(txtResDni);
        fR1.add(new JLabel("Hab N°:"));
        fR1.add(txtResNumHab);
        fR1.add(new JLabel("Días:"));
        fR1.add(txtResDias);
        panelRes.add(fR1);

        JPanel fR2 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        btnCheckIn = new JButton("Check-in");
        btnCheckOut = new JButton("Check-out");
        fR2.add(btnCheckIn);
        fR2.add(btnCheckOut);
        panelRes.add(fR2);

        JPanel fR3 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        btnAgregarServicio = new JButton("Agregar servicio");
        txtResServNombre = new JTextField(10);
        txtResServCantidad = new JTextField(3);
        fR3.add(btnAgregarServicio);
        fR3.add(new JLabel("Serv:"));
        fR3.add(txtResServNombre);
        fR3.add(new JLabel("Cant:"));
        fR3.add(txtResServCantidad);
        panelRes.add(fR3);

        panelRes.add(Box.createVerticalStrut(10));
        panelRes.add(crearLabelNegrita("Lista reservas"));
        modeloReservas = new DefaultListModel<>();
        listReservas = new JList<>(modeloReservas);
        panelRes.add(new JScrollPane(listReservas));

        btnCrearReserva.addActionListener(ev -> {
            try {
                String dni = txtResDni.getText().trim();
                int numHab = Integer.parseInt(txtResNumHab.getText().trim());
                int dias = Integer.parseInt(txtResDias.getText().trim());

                Huesped h = buscarHuespedUI(dni);
                Habitacion hab = buscarHabitacionUI(numHab);

                if (h == null || hab == null) {
                    JOptionPane.showMessageDialog(this, "Huésped o habitación no encontrados");
                    return;
                }

                Calendar cal = Calendar.getInstance();
                Date inicio = cal.getTime();
                cal.add(Calendar.DATE, dias);
                Date fin = cal.getTime();

                Reserva r = recep.crearReserva(h, hab, inicio, fin);
                if (r != null && cantReservasUI < reservasUI.length) {
                    reservasUI[cantReservasUI++] = r;
                    modeloReservas.addElement(r.VerInfo());
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Datos de reserva inválidos");
            }
        });

        btnCheckIn.addActionListener(ev -> {
            int idx = listReservas.getSelectedIndex();
            if (idx >= 0) {
                Reserva r = reservasUI[idx];
                recep.checkIn(r);
                modeloReservas.set(idx, r.VerInfo());
            } else {
                JOptionPane.showMessageDialog(this, "Seleccione una reserva");
            }
        });

        btnCheckOut.addActionListener(ev -> {
            int idx = listReservas.getSelectedIndex();
            if (idx >= 0) {
                Reserva r = reservasUI[idx];
                recep.checkOut(r); // backend ya marca finalizada y calcula total internamente

                int noches = r.calcularNoches();
                double costoHab = noches * r.getHabitacion().getPrecioPorNoche();
                double total = r.calcularTotal();
                double costoServ = total - costoHab;

                JOptionPane.showMessageDialog(this,
                        "FACTURA DE ESTADÍA\n\n" +
                        "Huésped: " + r.getHuesped().getNombres() + " " + r.getHuesped().getApellidos() + "\n" +
                        "Habitación: " + r.getHabitacion().getNumero() + "\n" +
                        "Noches: " + noches + "\n" +
                        "Costo Habitación: S/. " + costoHab + "\n" +
                        "Servicios adicionales: S/. " + costoServ + "\n\n" +
                        "TOTAL: S/. " + total,
                        "Factura", JOptionPane.INFORMATION_MESSAGE);

                modeloReservas.set(idx, r.VerInfo());
            } else {
                JOptionPane.showMessageDialog(this, "Seleccione una reserva");
            }
        });

        btnAgregarServicio.addActionListener(ev -> {
            int idxRes = listReservas.getSelectedIndex();
            if (idxRes < 0) {
                JOptionPane.showMessageDialog(this, "Seleccione una reserva");
                return;
            }
            String nomServ = txtResServNombre.getText().trim();
            int cant;
            try {
                cant = Integer.parseInt(txtResServCantidad.getText().trim());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Cantidad inválida");
                return;
            }
            ServicioAdicional s = buscarServicioUI(nomServ);
            if (s == null) {
                JOptionPane.showMessageDialog(this, "Servicio no encontrado");
                return;
            }
            Reserva r = reservasUI[idxRes];
            recep.agregarServicioAReserva(r, s, cant);
            modeloReservas.set(idxRes, r.VerInfo());
        });

        centro.add(panelHues);
        centro.add(panelRes);

        btnRecepReset = new JButton("Resetear Info");
        btnRecepLogout = new JButton("Cerrar sesión");

        btnRecepReset.addActionListener(ev -> {
            recep.resetearInformacion();
            JOptionPane.showMessageDialog(this, "Información del recepcionista reseteada.");
        });

        btnRecepLogout.addActionListener(ev -> cerrarSesion());

        JPanel sur = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        sur.add(btnRecepReset);
        sur.add(btnRecepLogout);

        panel.add(centro, BorderLayout.CENTER);
        panel.add(sur, BorderLayout.SOUTH);

        return panel;
    }

    private JLabel crearLabelNegrita(String texto) {
        JLabel l = new JLabel(texto);
        l.setFont(l.getFont().deriveFont(Font.BOLD));
        return l;
    }

    private Huesped buscarHuespedUI(String dni) {
        for (int i = 0; i < cantHuespedesUI; i++) {
            if (huespedesUI[i].getDni().equals(dni)) {
                return huespedesUI[i];
            }
        }
        return null;
    }

    private Habitacion buscarHabitacionUI(int numero) {
        for (int i = 0; i < cantHabUI; i++) {
            if (habitacionesUI[i].getNumero() == numero) {
                return habitacionesUI[i];
            }
        }
        return null;
    }

    private ServicioAdicional buscarServicioUI(String nombre) {
        for (int i = 0; i < cantServUI; i++) {
            if (serviciosUI[i].getNombre().equalsIgnoreCase(nombre)) {
                return serviciosUI[i];
            }
        }
        return null;
    }

    private String formatearEmpleado(Empleado e) {
        String rol;
        if (e instanceof Administrador) {
            rol = "Administrador";
        } else if (e instanceof Recepcionista) {
            rol = "Recepcionista";
        } else {
            rol = "Desconocido";
        }
        return e.VerInfo() + " | Rol: " + rol;
    }

    private Date parseFechaSimple(String texto) throws Exception {
        String[] p = texto.split("-");
        if (p.length != 3) {
            throw new Exception("Formato inválido");
        }
        int anio = Integer.parseInt(p[0]);
        int mes = Integer.parseInt(p[1]) - 1; // Calendar enero = 0
        int dia = Integer.parseInt(p[2]);

        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, anio);
        cal.set(Calendar.MONTH, mes);
        cal.set(Calendar.DAY_OF_MONTH, dia);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);

        return cal.getTime();
    }

    private void cerrarSesion() {
        empleadoActual = null;
        tabs.removeAll();
        tabs.add("Autenticador", panelAutenticador);
        tabs.setSelectedIndex(0);

        // limpiar campos de login
        txtAuthUsuario.setText("");
        txtAuthPassword.setText("");
        txtAuthDni.setText("");
        txtAuthNombres.setText("");
        txtAuthApellidos.setText("");
        txtAuthAcceso.setText("Concedido/Denegado");

        tabs.updateUI();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            VentanaHotel v = new VentanaHotel();
            v.setVisible(true);
        });
    }
}
