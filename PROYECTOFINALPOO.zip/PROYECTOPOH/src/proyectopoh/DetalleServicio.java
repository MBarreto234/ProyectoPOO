/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectopoh;

/**
 *
 * @author eduar
 */
public class DetalleServicio {
    private ServicioAdicional servicio;
    private int cantidad;
    
    public DetalleServicio(ServicioAdicional servicio, int cantidad) {
        this.servicio = servicio;
        this.cantidad = cantidad;
    }
    
    // Getters y Setters
    public ServicioAdicional getServicio() {
        return servicio;
    }
    public void setServicio(ServicioAdicional servicio) {
        this.servicio = servicio;
    }
    public int getCantidad() {
        return cantidad;
    }
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
    
    // Calcular subtotal (precio del servicio * cantidad)
    public double calcularSubtotal() {
        return servicio.getPrecio() * cantidad;
    }
    
    public String VerInfo() {
        return servicio.getNombre() + " x" + cantidad + " = S/. " + calcularSubtotal();
    }
}

