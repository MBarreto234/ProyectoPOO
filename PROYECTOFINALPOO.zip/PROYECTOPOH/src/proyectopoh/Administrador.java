/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectopoh;

/**
 *
 * @author eduar
 */
public class Administrador extends Empleado 
       implements GestionProcesosHabitaciones, GestionProcesosServicios {

    // ================== HABITACIONES ==================
    private static final Habitacion[] listaHabitaciones = new Habitacion[100];
    private static int totalHabitaciones = 0;

    // ================== SERVICIOS ==================
    private static final ServicioAdicional[] listaServicios = new ServicioAdicional[100];
    private static int totalServicios = 0;

    // ================== EMPLEADOS (NUEVO) ==================
    // Aquí el admin gestiona a otros empleados (admins y recepcionistas)
    private static final Empleado[] listaEmpleados = new Empleado[50];
    private static int totalEmpleados = 0;

    public Administrador(String dni, String nombres, String apellidos, 
                         String login, String password, boolean acceso) {
        super(dni, nombres, apellidos, login, password, acceso);
    }

    // Implementación del método abstracto
    @Override
    public void resetearInformacion() {
        setPassword("admin123");
        setAcceso(false);
    }

    // =========================================================
    // ===============   GESTIÓN DE HABITACIONES  ==============
    // =========================================================

    @Override
    public void registrarHabitacion(Habitacion hab) {
        if (totalHabitaciones < listaHabitaciones.length) {
            listaHabitaciones[totalHabitaciones++] = hab;
            System.out.println("Habitacion registrada: " + hab.getNumero() + " (" + hab.getTipo() + ")");
        } else {
            System.out.println("No se pueden agregar mas habitaciones (lista llena).");
        }
    }

    // Buscar índice de habitación por número (método auxiliar interno)
    private int encontrarIndiceHabitacion(int numero) {
        for (int i = 0; i < totalHabitaciones; i++) {
            if (listaHabitaciones[i].getNumero() == numero) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public void eliminarHabitacion(int numero) {
        int idx = encontrarIndiceHabitacion(numero);
        if (idx != -1) {
            listaHabitaciones[idx] = listaHabitaciones[totalHabitaciones - 1];
            listaHabitaciones[totalHabitaciones - 1] = null;
            totalHabitaciones--;
            System.out.println("Habitacion " + numero + " eliminada del sistema.");
        } else {
            System.out.println("Habitacion " + numero + " no encontrada.");
        }
    }

    @Override
    public void limpiarHabitacion(int numero) {
        int idx = encontrarIndiceHabitacion(numero);
        if (idx != -1) {
            listaHabitaciones[idx].setEstado("limpia");
            System.out.println("Habitacion " + numero + " marcada como limpia.");
        } else {
            System.out.println("Habitacion " + numero + " no encontrada.");
        }
    }

    @Override
    public void listarHabitaciones() {
        System.out.println("\nLista de Habitaciones:");
        for (int i = 0; i < totalHabitaciones; i++) {
            Habitacion h = listaHabitaciones[i];
            System.out.println("- Habitacion " + h.getNumero() + " (" + h.getTipo() + ") - Estado: " + h.getEstado() 
                               + " - Precio: S/. " + h.getPrecioPorNoche());
        }
    }

    // =========================================================
    // ===============     GESTIÓN DE SERVICIOS    =============
    // =========================================================

    @Override
    public void registrarServicio(ServicioAdicional serv) {
        if (totalServicios < listaServicios.length) {
            listaServicios[totalServicios++] = serv;
            System.out.println("Servicio adicional registrado: " + serv.getNombre());
        } else {
            System.out.println("No se pueden agregar mas servicios (lista llena).");
        }
    }

    // Buscar índice de servicio por nombre (método auxiliar interno)
    private int encontrarIndiceServicio(String nombre) {
        for (int i = 0; i < totalServicios; i++) {
            if (listaServicios[i].getNombre().equalsIgnoreCase(nombre)) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public void eliminarServicio(String nombre) {
        int idx = encontrarIndiceServicio(nombre);
        if (idx != -1) {
            listaServicios[idx] = listaServicios[totalServicios - 1];
            listaServicios[totalServicios - 1] = null;
            totalServicios--;
            System.out.println("Servicio '" + nombre + "' eliminado del sistema.");
        } else {
            System.out.println("Servicio '" + nombre + "' no encontrado.");
        }
    }

    @Override
    public void listarServicios() {
        System.out.println("\nLista de Servicios Adicionales:");
        for (int i = 0; i < totalServicios; i++) {
            ServicioAdicional s = listaServicios[i];
            System.out.println("- " + s.getNombre() + " (Precio: S/. " + s.getPrecio() + ")");
        }
    }

    // =========================================================
    // ===============   GESTIÓN DE EMPLEADOS     ==============
    // =========================================================

    // Buscar índice de empleado por DNI
    private int encontrarIndiceEmpleado(String dni) {
        for (int i = 0; i < totalEmpleados; i++) {
            if (listaEmpleados[i].getDni().equals(dni)) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Registrar un nuevo empleado.
     * rol: "ADMIN" / "ADMINISTRADOR" o "RECEPCIONISTA"
     */
    public void registrarEmpleado(String rol,
                                  String dni, String nombres, String apellidos,
                                  String login, String password) {

        if (totalEmpleados >= listaEmpleados.length) {
            System.out.println("No se pueden registrar mas empleados (lista llena).");
            return;
        }

        Empleado nuevo;

        // Según el rol, creamos un tipo u otro
        if (rol.equalsIgnoreCase("ADMIN") || rol.equalsIgnoreCase("ADMINISTRADOR")) {
            nuevo = new Administrador(dni, nombres, apellidos, login, password, true);
        } else {
            nuevo = new Recepcionista(dni, nombres, apellidos, login, password, true);
        }

        listaEmpleados[totalEmpleados] = nuevo;
        totalEmpleados++;

        System.out.println("Empleado registrado: " + nuevo.VerInfo());
    }

    /**
     * Modificar nombres y apellidos de un empleado.
     */
    public void modificarEmpleado(String dni,
                                  String nuevosNombres,
                                  String nuevosApellidos) {

        int idx = encontrarIndiceEmpleado(dni);

        if (idx != -1) {
            listaEmpleados[idx].setNombres(nuevosNombres);
            listaEmpleados[idx].setApellidos(nuevosApellidos);
            System.out.println("Empleado actualizado: " + listaEmpleados[idx].VerInfo());
        } else {
            System.out.println("Empleado con DNI " + dni + " no encontrado.");
        }
    }

    /**
     * Eliminar un empleado por DNI.
     */
    public void eliminarEmpleado(String dni) {
        int idx = encontrarIndiceEmpleado(dni);

        if (idx != -1) {
            listaEmpleados[idx] = listaEmpleados[totalEmpleados - 1];
            listaEmpleados[totalEmpleados - 1] = null;
            totalEmpleados--;

            System.out.println("Empleado con DNI " + dni + " eliminado.");
        } else {
            System.out.println("Empleado con DNI " + dni + " no encontrado.");
        }
    }

    /**
     * Listar empleados con su rol (Admin o Recepcionista).
     */
    public void listarEmpleados() {
        System.out.println("\nLista de Empleados:");
        for (int i = 0; i < totalEmpleados; i++) {
            Empleado e = listaEmpleados[i];
            String rol;
            if (e instanceof Administrador) {
                rol = "Administrador";
            } else if (e instanceof Recepcionista) {
                rol = "Recepcionista";
            } else {
                rol = "Desconocido";
            }
            System.out.println("- " + e.VerInfo() + " | Rol: " + rol);
        }
    }
}

