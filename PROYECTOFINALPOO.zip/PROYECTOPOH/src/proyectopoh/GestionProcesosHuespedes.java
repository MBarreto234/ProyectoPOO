/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package proyectopoh;

/**
 *
 * @author marce
 */
public interface GestionProcesosHuespedes {
    void registrarHuesped(Huesped h);
    void modificarHuesped(String dni, String nuevoTelefono);
    void eliminarHuesped(String dni);
    void listarHuespedes();
}
