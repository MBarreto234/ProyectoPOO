/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectopoh;

/**
 *
 * @author eduar
 */
public class Recepcionista extends Empleado 
       implements GestionProcesosHuespedes, GestionProcesosReservas {
    // Arreglos para gestionar huéspedes y reservas
    private static final Huesped[] listaHuespedes = new Huesped[100];
    private static int totalHuespedes = 0;
    private static final Reserva[] listaReservas = new Reserva[100];
    private static int totalReservas = 0;
    
    public Recepcionista(String dni, String nombres, String apellidos, 
                         String login, String password, boolean acceso) {
        super(dni, nombres, apellidos, login, password, acceso);
    }
    
    @Override
    public void resetearInformacion() {
        setPassword("1234");
        setAcceso(false);
    }
    
    @Override
    public void registrarHuesped(Huesped h) {
        if (totalHuespedes < listaHuespedes.length) {
            listaHuespedes[totalHuespedes++] = h;
            System.out.println("Huesped registrado: " + h.getNombres() + " " + h.getApellidos());
        } else {
            System.out.println("No se puede registrar más huéspedes (lista llena).");
        }
    }
    
    private int encontrarIndiceHuesped(String dni) {
        for (int i = 0; i < totalHuespedes; i++) {
            if (listaHuespedes[i].getDni().equals(dni)) {
                return i;
            }
        }
        return -1;
    }
    
    @Override
    public void modificarHuesped(String dni, String nuevoTelefono) {
        int idx = encontrarIndiceHuesped(dni);
        if (idx != -1) {
            listaHuespedes[idx].setTelefono(nuevoTelefono);
            System.out.println("Telefono del huesped con DNI " + dni + " actualizado.");
        } else {
            System.out.println("Huesped con DNI " + dni + " no encontrado.");
        }
    }
    
    @Override
    public void eliminarHuesped(String dni) {
        int idx = encontrarIndiceHuesped(dni);
        if (idx != -1) {
            listaHuespedes[idx] = listaHuespedes[totalHuespedes - 1];
            listaHuespedes[totalHuespedes - 1] = null;
            totalHuespedes--;
            System.out.println("Huesped con DNI " + dni + " eliminado.");
        } else {
            System.out.println("Huesped con DNI " + dni + " no encontrado.");
        }
    }
    
    @Override
    public Reserva crearReserva(Huesped huesped, Habitacion habitacion, java.util.Date fechaInicio, java.util.Date fechaFin) {
        if (totalReservas < listaReservas.length) {
            if (!"ocupada".equalsIgnoreCase(habitacion.getEstado())) {
                Reserva nueva = new Reserva(huesped, habitacion, fechaInicio, fechaFin, "Reservada");
                listaReservas[totalReservas++] = nueva;
                habitacion.setEstado("ocupada");
                System.out.println("\nReserva creada para huesped " + huesped.getNombres() + " en habitacion " + habitacion.getNumero());
                return nueva;
            } else {
                System.out.println("La habitacion " + habitacion.getNumero() + " ya esta ocupada.");
                return null;
            }
        } else {
            System.out.println("No se pueden crear mas reservas (lista llena).");
            return null;
        }
    }
    
    @Override
    public void checkIn(Reserva reserva) {
        if (reserva != null) {
            reserva.setEstado("Activa");
            reserva.getHabitacion().setEstado("ocupada");
            System.out.println("\nCheck-in realizado para la reserva de " + reserva.getHuesped().getNombres());
        }
    }
    
    @Override
    public void checkOut(Reserva reserva) {
        if (reserva != null) {
            reserva.setEstado("Finalizada");
            reserva.getHabitacion().setEstado("sucia");
            System.out.println("\nCheck-out realizado para la reserva de " + reserva.getHuesped().getNombres());
            // Calcular el total de la cuenta (habitación + servicios adicionales)
            double total = reserva.calcularTotal();
            System.out.println("\nTotal a pagar por la estadia: S/. " + total);
        }
    }
    
    @Override
    public void agregarServicioAReserva(Reserva reserva, ServicioAdicional servicio, int cantidad) {
        if (reserva != null) {
            reserva.agregarDetalleServicio(servicio, cantidad);
            System.out.println("Servicio \"" + servicio.getNombre() + "\" agregado a la reserva del huesped " + reserva.getHuesped().getNombres());
        }
    }
    
    @Override
    public void listarHuespedes() {
        System.out.println("\nLista de Huespedes:");
        for (int i = 0; i < totalHuespedes; i++) {
            Huesped h = listaHuespedes[i];
            System.out.println("- " + h.getNombres() + " " + h.getApellidos() + " (DNI: " + h.getDni() + ")");
        }
    }
    
    @Override
    public void listarReservas() {
        System.out.println("\nLista de Reservas:");
        for (int i = 0; i < totalReservas; i++) {
            Reserva r = listaReservas[i];
            System.out.println("- Reserva de " + r.getHuesped().getNombres() + " en hab. " + r.getHabitacion().getNumero() + 
                               " | Estado: " + r.getEstado() + "");
        }
    }
}
