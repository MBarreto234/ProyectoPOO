/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectopoh;

/**
 *
 * @author eduar
 */
import java.util.Date;
import java.util.Calendar;

public class Main {
    public static void main(String[] args) {
        // 1. Crear un administrador y un recepcionista
        Administrador admin = new Administrador("0001", "Carlos", "Perez", "carlos", "adminpass", true);
        Recepcionista recep = new Recepcionista("0002", "Ana", "Gomez", "ana", "receppass", true);
        
        System.out.println(admin.VerInfo());
        
        System.out.println("\n" +recep.VerInfo());
        
        // 2. El administrador registra habitaciones disponibles
        
        Habitacion hab101 = new Habitacion(101, "Simple", 150.0, "limpia");
        System.out.println(hab101.VerInfo());
        
        Habitacion hab102 = new Habitacion(102, "Doble", 200.0, "limpia");
        System.out.println(hab102.VerInfo());
        
        System.out.println("");
        admin.registrarHabitacion(hab101);
        System.out.println("");
        admin.registrarHabitacion(hab102);
        
        
        // 3. El recepcionista registra un huésped
        Huesped huesped1 = new Huesped("12345678", "Juan", "Lopez", "987654321");
        System.out.println("");
        recep.registrarHuesped(huesped1);
        
        // El administrador registra servicios adicionales ofrecidos
        System.out.println("");
        ServicioAdicional desayuno = new ServicioAdicional("Desayuno", 20.0);
        admin.registrarServicio(desayuno);
        System.out.println(desayuno.VerInfo());
        System.out.println("");
        ServicioAdicional spa = new ServicioAdicional("Spa", 50.0);
        admin.registrarServicio(spa);
        System.out.println(spa.VerInfo());
        
        // 4. El recepcionista crea una reserva para el huésped en la habitación 101 (por 2 noches)
        Calendar cal = Calendar.getInstance();
        Date hoy = cal.getTime();               // fecha de hoy
        cal.add(Calendar.DATE, 2);
        Date fechaSalida = cal.getTime();       // hoy + 2 días
        Reserva reserva1 = recep.crearReserva(huesped1, hab101, hoy, fechaSalida);
        System.out.println("");
        System.out.println(reserva1.VerInfo());
        
        // Agregar servicios adicionales a la reserva (2 desayunos)
        recep.agregarServicioAReserva(reserva1, desayuno, 2);
        
        // 5. Realizar check-in del huésped cuando llega
        recep.checkIn(reserva1);
        // (Durante la estadía el huésped usa el spa una vez)
        recep.agregarServicioAReserva(reserva1, spa, 1);
        // Realizar check-out al final de la estadía
        recep.checkOut(reserva1);
        
        // 6. Después del check-out, el administrador marca la habitación 101 como limpia nuevamente
        admin.limpiarHabitacion(101);
        
        // 7. Listar todos los datos para verificar estado final
        recep.listarHuespedes();
        admin.listarHabitaciones();
        admin.listarServicios();
        recep.listarReservas();
        
        // 8. Demostración de polimorfismo con arreglo de Empleados
        Empleado[] empleados = new Empleado[2];
        empleados[0] = recep;  // un Recepcionista es un Empleado
        empleados[1] = admin;  // un Administrador es un Empleado
        // Invocar método abstracto (implementado en subclases) en cada empleado
        for (Empleado emp: empleados) {
            emp.resetearInformacion();
        }
        // Mostrar información de empleados tras resetear
        System.out.println("\n--------EMPLEADOS CON PERMISOS REMOVIDOS----------");
        System.out.println("\n" +recep.VerInfo());
        System.out.println("\n" + admin.VerInfo());
    }
}

