/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectopoh;

/**
 *
 * @author eduar
 */
public abstract class Empleado implements Autenticacion {
    protected String dni;
    protected String nombres;
    protected String apellidos;
    protected String login;
    protected String password;
    protected boolean acceso;
    
    public Empleado(String dni, String nombres, String apellidos, String login, String password, boolean acceso) {
        this.dni = dni;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.login = login;
        this.password = password;
        this.acceso = acceso;
    }
    
    // Getters y Setters para encapsulación
    public String getDni() {
        return dni;
    }
    public void setDni(String dni) {
        this.dni = dni;
    }
    public String getNombres() {
        return nombres;
    }
    public void setNombres(String nombres) {
        this.nombres = nombres;
    }
    public String getApellidos() {
        return apellidos;
    }
    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }
    public String getLogin() {
        return login;
    }
    public void setLogin(String login) {
        this.login = login;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public boolean isAcceso() {
        return acceso;
    }
    public void setAcceso(boolean acceso) {
        this.acceso = acceso;
    }
    
    // Método abstracto que las subclases deben implementar
    @Override
    public abstract void resetearInformacion();
    
    public String VerInfo() {
        return "Empleado[" + dni + " - " + nombres + " " + apellidos + ", login=" + login + ", acceso=" + acceso + "]";
    }
    
    @Override
    public boolean iniciarSesion(String login, String password) {
        return this.login.equals(login) && this.password.equals(password);
    }
}

