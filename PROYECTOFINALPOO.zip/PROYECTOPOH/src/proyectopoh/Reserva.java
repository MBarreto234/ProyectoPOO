/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectopoh;

/**
 *
 * @author eduar
 */
import java.util.Date;

public class Reserva implements Facturacion {
    private Huesped huesped;
    private Habitacion habitacion;
    private Date fechaInicio;
    private Date fechaFin;
    private String estado; // e.g. "Reservada", "Activa", "Finalizada"
    private final DetalleServicio[] detallesServicios;
    private int totalDetalles = 0;
    
    public Reserva(Huesped huesped, Habitacion habitacion, Date fechaInicio, Date fechaFin, String estado) {
        this.huesped = huesped;
        this.habitacion = habitacion;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.estado = estado;
        this.detallesServicios = new DetalleServicio[50]; // capacidad para 50 servicios adicionales por reserva
    }
    
    // Getters y Setters
    public Huesped getHuesped() {
        return huesped;
    }
    public void setHuesped(Huesped huesped) {
        this.huesped = huesped;
    }
    public Habitacion getHabitacion() {
        return habitacion;
    }
    public void setHabitacion(Habitacion habitacion) {
        this.habitacion = habitacion;
    }
    public Date getFechaInicio() {
        return fechaInicio;
    }
    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }
    public Date getFechaFin() {
        return fechaFin;
    }
    public void setFechaFin(Date fechaFin) {
        this.fechaFin = fechaFin;
    }
    public String getEstado() {
        return estado;
    }
    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    // Agregar un detalle de servicio adicional a la reserva
    public void agregarDetalleServicio(ServicioAdicional servicio, int cantidad) {
        if (totalDetalles < detallesServicios.length) {
            detallesServicios[totalDetalles++] = new DetalleServicio(servicio, cantidad);
        }
    }
    
    // Calcula la cantidad de noches entre fechaInicio y fechaFin
    public int calcularNoches() {
        long diffMilli = fechaFin.getTime() - fechaInicio.getTime();
        long dias = diffMilli / (1000 * 60 * 60 * 24);
        return (int) dias;
    }
    
    // Calcula el total a pagar por la reserva (costo habitación + servicios adicionales)
    @Override
    public double calcularTotal() {
        int noches = calcularNoches();
        double costoHabitacion = habitacion.getPrecioPorNoche() * noches;
        double costoServicios = 0;
        for (int i = 0; i < totalDetalles; i++) {
            costoServicios += detallesServicios[i].calcularSubtotal();
        }
        return costoHabitacion + costoServicios;
    }
    
    public String VerInfo() {
        return "Reserva[" + huesped.getNombres() + " en hab. " + habitacion.getNumero() + " del " 
               + fechaInicio + " al " + fechaFin + ", estado=" + estado + "]";
    }
}

